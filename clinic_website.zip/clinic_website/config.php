<?php
// Database configuration
$servername = "localhost";  // Change this if your database server is different
$username = "root";         // Default username for XAMPP
$password = "";             // Default password for XAMPP (usually empty)
$dbname = "clinic_website"; // Your database name

try {
    // Create a new PDO connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Success message (optional)
    // echo "Connected successfully";
} catch (PDOException $e) {
    // Handle connection error
    echo "Connection failed: " . $e->getMessage();
}
?>

